
import sqlite3
conn = sqlite3.connect('bot_config.db')
cursor = conn.cursor()

token = '7899182029:AAG6xh4F1JaK9U8iMAN5soorFid_8ArYY9o'
Dev_Zaid = token.split(':')[0]
sudo_id = 6911469858
botUsername = 'w7p_bot'
from kvsqlite.sync import Client as DB
ytdb = DB('ytdb.sqlite')
sounddb = DB('sounddb.sqlite')
wsdb = DB('wsdb.sqlite')