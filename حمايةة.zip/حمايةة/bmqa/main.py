import time, os, json, re, requests, asyncio, subprocess, sys
import sqlite3  # استيراد مكتبة SQLite
from pyrogram import *


# إنشاء أو الاتصال بقاعدة بيانات SQLite
conn = sqlite3.connect('bot_config.db')
cursor = conn.cursor()

# إنشاء جدول لتخزين إعدادات البوت
cursor.execute('''
CREATE TABLE IF NOT EXISTS bot_config (
    key TEXT PRIMARY KEY,
    value TEXT
)
''')

def get_value(key):
    cursor.execute('SELECT value FROM bot_config WHERE key = ?', (key,))
    result = cursor.fetchone()
    return result[0] if result else None

def set_value(key, value):
    cursor.execute('INSERT OR REPLACE INTO bot_config (key, value) VALUES (?, ?)', (key, value))
    conn.commit()

print('''
Loading…
█▒▒▒▒▒▒▒▒▒''')
print('\n\n')

try:
    from information import *
    Dev_Zaid = token.split(':')[0]
    set_value(f'{Dev_Zaid}botowner', owner_id)
except Exception as e:
    with open('information.py', 'w+') as www:
        token = input('[+] Enter the bot token : ')
        Dev_Zaid = token.split(':')[0]
        if not get_value(f'{Dev_Zaid}botowner'):
            owner_id = int(input('[+] Enter SUDO ID : '))
            set_value(f'{Dev_Zaid}botowner', owner_id)
        else:
            owner_id = int(get_value(f'{Dev_Zaid}botowner'))
        text = 'token = "{}"\nowner_id = {}'
        www.write(text.format(token, owner_id))

if not get_value(f'{Dev_Zaid}botowner'):
    owner_id = int(input('[+] Enter SUDO ID : '))
    set_value(f'{Dev_Zaid}botowner', owner_id)
else:
    owner_id = int(get_value(f'{Dev_Zaid}botowner'))
print('''
10% 
███▒▒▒▒▒▒▒ ''')

to_config = """
import sqlite3
conn = sqlite3.connect('bot_config.db')
cursor = conn.cursor()
"""

to_config += f"\ntoken = '{token}'"
to_config += f"\nDev_Zaid = token.split(':')[0]"
to_config += f"\nsudo_id = {owner_id}"
username = requests.get(f"https://api.telegram.org/bot{token}/getMe").json()["result"]["username"]
to_config += f"\nbotUsername = '{username}'"
to_config += "\nfrom kvsqlite.sync import Client as DB"
to_config += "\nytdb = DB('ytdb.sqlite')"
to_config += "\nsounddb = DB('sounddb.sqlite')"
to_config += "\nwsdb = DB('wsdb.sqlite')"

print('''
30% 
█████▒▒▒▒▒ ''')
with open('config.py', 'w+') as w:
    w.write(to_config)
print('''
50% 
███████▒▒▒ ''')

app = Client(f'{Dev_Zaid}r3d', 28262069, '2c23a5db37b1490193e5e5e5e7957747c7',
              bot_token=token,
              plugins={"root": "Plugins"},
              )

if not get_value(f'{Dev_Zaid}:botkey'):
    set_value(f'{Dev_Zaid}:botkey', '⇜')

if not get_value(f'{Dev_Zaid}botname'):
    set_value(f'{Dev_Zaid}botname', 'نانا')

if not get_value(f'{Dev_Zaid}botchannel'):
    set_value(f'{Dev_Zaid}botchannel', 'eFFb0t')

def Find(text):
    m = r"(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|([^\s()<>]+|([^\s()<>]+))*)+(?:([^\s()<>]+|([^\s()<>]+))*|[^\s!(){};:'\".,<>?«»“”‘’]))"
    url = re.findall(m, text)  
    return [x[0] for x in url]

app.start()

print('''
[===========================]

█████╗░██████╗░██████╗░
██╔══██╗╚════██╗██╔══██╗
██████╔╝░█████╔╝██║░░██║
██╔══██╗░╚═══██╗██║░░██║
██║░░██║██████╔╝██████╔╝
╚═╝░░╚═╝╚═════╝░╚═════╝░

[===========================]

🔮 Your bot started successfully on R 3 D ☆ Source 🔮

•••••••• @yqyqy66 - @yqyqy66 •••••••••


''')
print('''
100% 
██████████''')
if get_value(f'DevGroup:{Dev_Zaid}'):
    id = int(get_value(f'DevGroup:{Dev_Zaid}'))
    try:
        app.send_message(id, "تم اتشغيل البوت بنجاح ✔️")
    except:
        pass

idle()

# لا تنسَ إغلاق الاتصال عند الانتهاء
conn.close()